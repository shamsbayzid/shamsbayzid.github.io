README for ASTRAL
Paper: ASTRAL: Genome-Scale Coalescent-Based Species Tree Estimation from Bootstrap Gene Trees
Authors: R. Reaz, Md. S. Bayzid, M. S. Swenson and T. Warnow


Naive Quartet Method:

We first run Naive Quartet Method on the best quartets (for every four species, we take the quartet with the highest weight) to see if there exists any tree satisfying all the best quartets. We return that tree if such a tree exists. Otherwise, we run our heuristic approach to find the tree that maximize the total weight of the satisfied quartets. Below are the instructions for running our heuristic method.


Executable Name: WQFM_Final_ISMB
Execution Command: WQFM_Final_ISMB <inputfile> <outputfile>

Input file format: 
	- Must contain one quartet and its weight (separated by space) per line.
	- Quartets should be in 'newick' format.
	- 0 cannot be the name of a taxon

	Example: 
		((a,b),(c,d)) 100;
		((cat,dog),(fish,human)) 200;
		((1,2),(e,f)) 230;

Supporting Files/packages:
	
	Package: bioPerl-1.5.2

	File: reroot_tree_new.pl
		- Users need to set the library path (line 3 of reroot_tree_new.pl) that points to bioPerl-1.5.2/lib/perl5.
		- This file MUST be placed in the PRESENT WORKING DIRECTORY.


Please email rezwana AT cs.utexas.edu or bayzid AT cs.utexas.edu if you have any question. 

	


		


